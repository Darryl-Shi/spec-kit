# OpenAI Codex CLI - Quickstart

Install:
- npm: `npm i -g @openai/codex`
- Homebrew: `brew install codex`

Use:
- Interactive: `codex`
- One-off: `codex exec "<your prompt>"`

This template includes prompts under `.codex/prompts/` you can open and paste into Codex, then adapt for your repo.
